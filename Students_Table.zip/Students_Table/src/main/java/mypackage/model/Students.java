package mypackage.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "students")
public class Students {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // auto create and autoincrement
	private int student_id;
	private String student_name;
	private String qualification;
	private float percentage;
	
	public Students() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Students(int student_id, String student_name, String qualification, float percentage) {
		super();
		this.student_id = student_id;
		this.student_name = student_name;
		this.qualification = qualification;
		this.percentage = percentage;
	}
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	
}
