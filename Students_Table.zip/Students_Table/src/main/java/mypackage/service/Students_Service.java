package mypackage.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mypackage.model.Students;
import mypackage.repository.Students_Repository;

@Service
public class Students_Service {
	@Autowired
	Students_Repository repository;
	
	public List<Students>GetAllStudents(){ // for 'GET' method
		List<Students> list = new ArrayList<Students>();
		for(Students s:repository.findAll()) {
			Students st = new Students(s.getStudent_id(), s.getStudent_name(), s.getQualification(), s.getPercentage());
			list.add(st);
		}
		return list;
	}
	
	public Students GetStudentById(int id) { // for 'GET' method
		Students student = repository.findById(id).get();
		return student;
	}
	
	public void AddStudent(Students s) { // for 'POST' method
		repository.save(s);
	}
	
	public void UpdateStudent(Students s) { // for 'PUT' method
		repository.save(s);
	}
	
	public void DeleteStudent(int id) { // for 'DELETE' method
		for(Students s:repository.findAll()) {
			if(s.getStudent_id() == id) {
				Students student = new Students(s.getStudent_id(), s.getStudent_name(), s.getQualification(), s.getPercentage());
				repository.delete(student);
			}
		}
	}
}
