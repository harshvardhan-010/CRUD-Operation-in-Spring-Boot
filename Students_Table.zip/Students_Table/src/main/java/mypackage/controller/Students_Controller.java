package mypackage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import mypackage.model.Students;
import mypackage.service.Students_Service;

@RestController
public class Students_Controller {
	
	@Autowired
	Students_Service service;
	
	// localhost:9090/api/students <-- Use this api if we're using XAMPP
	// 									and cross check through Postman App
	
	@GetMapping("api/students")
	public List<Students> GetAll(){
		return service.GetAllStudents();
	}
	
	@GetMapping("api/students/{id}")
	public Students GetById(@PathVariable("id")int id) {
		return service.GetStudentById(id);
	}
	
	@PostMapping("api/students")
	public String Add(@RequestBody Students s) {
		service.AddStudent(s);
		return "Student Added Successfully";
	}
	
	@PutMapping("api/students")
	public String Update(@RequestBody Students s) {
		service.UpdateStudent(s);
		return "Student Updated Successfully";
	}
	
	@DeleteMapping("api/students/{id}")
	public String Delete(@PathVariable("id")int id) {
		service.DeleteStudent(id);
		return "Student Deleted Successfully";
	}
}
