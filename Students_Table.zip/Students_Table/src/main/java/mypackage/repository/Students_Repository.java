package mypackage.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import mypackage.model.Students;

public interface Students_Repository extends JpaRepository<Students, Integer> {

}
